// empty custom assertion needed for git to keep track of the folder
module.exports.assertion = function () {};
